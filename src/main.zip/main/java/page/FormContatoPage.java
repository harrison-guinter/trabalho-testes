package page;

import dsl.DSL;
import org.openqa.selenium.WebDriver;

public class FormContatoPage {

    private DSL dsl;

    public FormContatoPage(WebDriver driver) {
        dsl = new DSL(driver);
    }

    public void setFirstName(String nome) {
        dsl.escrever("fname", nome);
    }

    public String getFirstName() {
        return dsl.obterValorCampo("fname");
    }

    public void setLastName(String sobrenome) {
        dsl.escrever("lname", sobrenome);
    }

    public String getLastName() {
        return dsl.obterValorCampo("lname");
    }

    public void setEmail(String email) {
        dsl.escrever("email", email);
    }

    public String getEmail() {
        return dsl.obterValorCampo("email");
    }

    public void setCountry(String pais) {
        dsl.selecionarCombo("country", pais);
    }

    public String getCountry() {
        return dsl.obterValorCombo("country");
    }

    public void setSubject(String texto) {
        dsl.escrever("subject", texto);
    }

    public String getSubject() {
        return dsl.obterValorCampo("subject");
    }

    public void marcarSendCopy() {
        if (!dsl.isCheckMarcado("scopy")) {
            dsl.clicarCheck("scopy");
        }
    }

    public void desmarcarSendCopy() {
        if (dsl.isCheckMarcado("scopy")) {
            dsl.clicarCheck("scopy");
        }
    }

    public boolean isSendCopyMarcado() {
        return dsl.isCheckMarcado("scopy");
    }

    public void submitForm() {
        dsl.clicarBotao("signin");
    }
}
