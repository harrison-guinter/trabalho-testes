package br.ifrs.selenium;

import dsl.DSL;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;


public class FormCadastroPage {
	private DSL dsl;
	
	public FormCadastroPage(WebDriver driver) {
		dsl = new DSL(driver);
	}
	
	// Campo: Email
	public void setEmail(String email) {
		dsl.escrever("email", email);
	}
	public String getEmail() {
		return dsl.obterValorCampo("email");
	}
	
	// Campo: Senha
	public void setSenha(String senha) {
		dsl.escrever("psw", senha);
	}
	public String getSenha() {
		return dsl.obterValorCampo("psw");
	}
	
	// Campo: Confirmação Senha
	public void setConfirmacaoSenha(String csenha) {
		dsl.escrever("psw-repeat", csenha);
	}
	public String getConfirmacaoSenha() {
		return dsl.obterValorCampo("psw-repeat");
	}
	
	// Campo: Country
	public void setPais(String pais) {
		dsl.selecionarCombo("country", pais);
	}
	public String getPais() {
		return dsl.obterValorCombo("country");
	}
	
	// Campo: Sports preferences
	public void setPreferenciaEsporte(String preferencia) {
		dsl.selecionarCombo("spreferences", preferencia);
	}
	public int getQtdePreferenciasEsporte() {
		return dsl.obterQuantidadeOpcoesCombo("spreferences");
	}
	
	// Campo: Age
	public void setIdadeMenor18() {
		dsl.clicarRadio("age1");
	}
	public boolean getIdadeMenor18() {
		return dsl.isRadioMarcado("age1");
	}	
	public void setIdadeMaior18Menor60() {
		dsl.clicarRadio("age2");
	}
	public boolean getIdadeMaior18Menor60() {
		return dsl.isRadioMarcado("age2");
	}	
	public void setIdadeMaior60() {
		dsl.clicarRadio("age3");
	}
	public boolean getIdadeMaior60() {
		return dsl.isRadioMarcado("age3");
	}
	
	// URl
	public void clicarTermsAndPrivacy() {
		dsl.clicarLink("Terms and Privacy");
	}
	public String getLinkTermsAndPrivacy() {
		//dsl.obterTexto(By.className("sterms");
		return dsl.obterTexto("idsterms");
	}
	
	// Botoes
	public void abrirCadastro() {
		dsl.clicarBotao("bsignup");
	}
	public void cadastrar() {
		dsl.clicarBotao("ssignup");
	}
}
