package exemplos;


import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.firefox.FirefoxDriver;;

public class TesteInteracaoFormSignup {

	private WebDriver driver;
	private br.ifrs.selenium.FormCadastroPage form;

	@Before
	public void setUp() {
		WebDriverManager.firefoxdriver().setup();
		driver = new FirefoxDriver();
		driver.get("file:///" + System.getProperty("user.dir") + "/src/main/resources/html/signup_form.html");
		form = new br.ifrs.selenium.FormCadastroPage(driver);
		form.abrirCadastro();
	}

	@After
	public void tearDown() {
		if (driver != null) {
			driver.quit();
		}
	}

	@Test
	public void deveInteragirComRadioButton() {
		form.setIdadeMaior18Menor60();
		Assert.assertTrue(form.getIdadeMaior18Menor60());
	}

	@Test
	public void deveInteragirComCombo() {
		form.setPais("Brazil");
		Assert.assertEquals("Brazil", form.getPais());
	}

	@Test
	public void deveInteragirComComboSelecaoMultipla() {
		form.setPreferenciaEsporte("Soccer");
		form.setPreferenciaEsporte("Football");
		Assert.assertEquals(2, form.getQtdePreferenciasEsporte());
	}

	@Test
	public void deveInteragirComLink() {
		form.clicarTermsAndPrivacy();
		Assert.assertTrue(form.getLinkTermsAndPrivacy().contains("Link Terms and Privacy clicado!"));
	}
}
