package exemplos;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import page.FormContatoPage;
import io.github.bonigarcia.wdm.WebDriverManager;


public class TesteInteracaoFormContato {

    private WebDriver driver;
    private FormContatoPage page;

    private final String FORM_HTML_PATH = "file:///" + System.getProperty("user.dir") + "\\src\\main\\resources\\html\\contact_form.html";

    @Before
    public void setUp() {
        WebDriverManager.firefoxdriver().setup();
        driver = new FirefoxDriver();
        driver.get(FORM_HTML_PATH);
        page = new FormContatoPage(driver);
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }

    @Test
    public void deveInteragirComTextField() {
        page.setFirstName("Batman");
        Assert.assertEquals("Batman", page.getFirstName());
    }

    @Test
    public void deveInteragirComTextArea() {
        String mensagem = "Mensagem de contato\ncontinua na linha 2...";
        page.setSubject(mensagem);
        Assert.assertEquals(mensagem, page.getSubject());
    }

    @Test
    public void deveInteragirComCheckbox() {
        page.marcarSendCopy();
        Assert.assertTrue(page.isSendCopyMarcado());
    }
}

